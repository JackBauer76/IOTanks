var annotated =
[
    [ "DS3231_Simple", "class_d_s3231___simple.html", "class_d_s3231___simple" ]
];