var files =
[
    [ "DS3231_Simple.h", "_d_s3231___simple_8h_source.html", null ]
];