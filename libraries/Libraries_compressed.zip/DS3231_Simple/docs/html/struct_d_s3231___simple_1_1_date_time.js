var struct_d_s3231___simple_1_1_date_time =
[
    [ "Day", "struct_d_s3231___simple_1_1_date_time.html#abf7c8772a03d62d2b15ac25e9863ab92", null ],
    [ "Dow", "struct_d_s3231___simple_1_1_date_time.html#af71938741794a77fb87933405630af59", null ],
    [ "Hour", "struct_d_s3231___simple_1_1_date_time.html#ae5a4bd5f8a9244d6c66338979c8b09a1", null ],
    [ "Minute", "struct_d_s3231___simple_1_1_date_time.html#a00805f9f5dbeb01a83e3e04acc03278f", null ],
    [ "Month", "struct_d_s3231___simple_1_1_date_time.html#a8a88cb3a5830f31aec53e592d3ae8447", null ],
    [ "Second", "struct_d_s3231___simple_1_1_date_time.html#a143ceae80037e76f6b69b2a044cffe6f", null ],
    [ "Year", "struct_d_s3231___simple_1_1_date_time.html#a0369348b5d4bdbd40e7e1d49c5bffb01", null ]
];